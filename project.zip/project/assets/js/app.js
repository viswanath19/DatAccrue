var categoryFields = [
        {
            "field": "Aadhaar",
            "value": "Aadhaar",
        },{
            "field": "ABN",
            "value": "ABN",
        },{
            "field": "ACN",
            "value": "ACN",
        },{
            "field": "Address",
            "value": "Address",
        },{
            "field": "Age",
            "value": "Age",
        },{
            "field": "Blood Group",
            "value": "Blood-Group",
        },{
            "field": "City",
            "value": "City",
        },{
            "field": "Names",
            "value": "Names",
        },{
            "field": "Credit Card",
            "value": "Credit-Card",
        },{
            "field": "Email",
            "value": "Email",
        },{
            "field": "Gender",
            "value": "Gender",
        },{
            "field": "Geo Coordinates",
            "value": "Geo-Coordinates",
        },{
           "field": "Height",
            "value": "Height",
        },{
            "field": "Occupation",
            "value": "Occupation",
        },{
            "field": "PAN",
            "value": "PAN",
        },{
            "field": "Phone",
            "value": "Phone",
        },{
            "field": "SSN",
            "value": "SSN",
        },{
            "field": "State",
            "value": "State",
        },{
            "field": "Weight",
            "value": "Weight",
        },{
            "field": "Zip",
            "value": "Zip",
        },{
            "field": "Zodiac Sign",
            "value": "Zodiac-Sign",
        }
	]

    var groupData = [
        {
			"language": "jQuery",
			"value": 122
		},
		{
			"language": "AngularJS",
			"value": 643
		},
		{
			"language": "ReactJS",
			"value": 422
		},
		{
			"language": "VueJS",
			"value": 622
		}
    ];
	var selectedData=[];
    var settings = {
        "inputId": "languageInput",
        //"data": languages,
        "data": categoryFields,
        "itemName": "field",
        //"groupItemName": "groupName",
        //"groupListName" : "groupData",
        "container": "transfer",
        "valueName": "value",
        "callable" : function (data, names) {
            console.log("Selected ID：" + data)
            $("#selectedItemSpan").text(names)
			selectedData=data;
			if(selectedData.length!=0){
				document.getElementById('alert1').style.display='none';
				document.getElementById('triangle1').style.display='none';
			}
			console.log(selectedData);
			
        }
    };

    Transfer.transfer(settings);
	let app = angular.module("gen-app",[]);
	app.controller('genAppCntrl',function($scope){
		$scope.isActive	= 1;
		$scope.rowvalues = []
		$scope.maxRows = 1000;
		for(let i = 50; i<=$scope.maxRows; i+=50){
			$scope.rowvalues.push({text:i,value:i});
		}
		/*
		$scope.categories = [
			{name:"Individual",value:1,iconclass:"fa-user"},
			{name:"Organization",value:2,iconclass:"fa-building"},
			{name:"Insurance",value:3,iconclass:"fa-umbrella"},
			{name:"Biometric",value:4,iconclass:"fa-user-md"},
			{name:"Country Based",value:5,iconclass:"fa-globe"},
			{name:"Banking",value:6,iconclass:"fa-university"},
			//{name:"AAAAA",value:7,iconclass:""},
			//{name:"BBBBB",value:8,iconclass:""},
		];
		*/
		$scope.typesOfExport = [
			{name:'CSV',value:0,iconclass:"fa-file"},
			{name:'HTML',value:1,iconclass:"fa-file-code"},
			{name:'JSON',value:2,iconclass:"fa-list-alt"},
			{name:'Excel',value:3,iconclass:"fa-file-excel"},
			
		];
		$scope.beforGen = function(){
			console.log(formatSelected);
			console.log(selectedData.length);
			if(formatSelected==''){
				console.log("Please select the format "+formatSelected.length);
				document.getElementById('alert').style.display='inline-block';
				document.getElementById('triangle').style.display='inline-block';
				
				//confirm("Please select the required format to export the data");
			}
			if(selectedData.length==0){
				document.getElementById('alert1').style.display='inline-block';
				document.getElementById('triangle1').style.display='inline-block';
				//$("#selectedFieldsCheck").modal('show');
				//confirm("Please select at least one field to export the data");
			}
			if(formatSelected.length!=0&&selectedData!=0){
			$("#myModal").modal('show');		
			}			
		}
		
	});
	$(document).ready(function() {
      setTimeout(function(){
		  if($(".tab-item-name").length > 0){
			var tabitem = $(".tab-item-name");
			console.log("<<<<tabitem>>>",tabitem);
			let currentList0 = tabitem[0],
				list1 = tabitem[1];
			$(currentList0).hide();
			list1 != undefined ? $(list1).trigger('click') : "";
			
		  }
		  
	  },500);
	  
    });
	var formatSelected='';
	function selectedItem(value){
		console.log(value);
		formatSelected=value;
		document.getElementById('alert').style.display='none';
		document.getElementById('triangle').style.display='none';
		console.log("Entered");
		
	}
	var fname='';
	function checked(){
		
	}
	function checkedFields(){
		$("#selectedFieldsCheck").modal('hide');
	}
	
	function getSelectedItems(){
		console.log("Entered");
		console.log(formatSelected);
		console.log(selectedData);
		var noofrowsSelected=document.getElementById('noofrowsselected').value;
		fname=document.getElementById('name').value;
		console.log(fname);
		console.log(noofrowsSelected);
		var age={};
		//var names={};
		var jsonage={};
		var totalAge=[];
		var phoneNumber=[];
		console.log(phoneNumber.length);
		var emailAddress=[];
		var aadharNumbers=[];
		var names=["Ankit",	"Aruna",	"Sashwat",	"Ayesha",	"Triveni",	"Rajesh",	"Shiva",	"Shiv ",	"Tasleem",	"Sasanka",	"Naveen",	"Dedepya",	"Sid",	"Lavanya",	"Rahul",	"Srini",	"Lanka",	"Pavan",	"Anup",	"Sudheer",	"Yaswant",	"Bharadwaj",	"Lakshmi",	"Alok",	"Aswin",	"Sai",	"Gowtham",	"Pallavi",	"Sirisha",	"Mayur",	"Nilesh",	"Sudharshan",	"Swaroop",	"Kalyan",	"Pranay",	"Ramesh",	"Kartheek",	"Sathesh",	"Viswanath",	"Pankaj",	"Vijay",	"Krishna",	"Susmit",	"Alekya",	"Sindhu",	"Prasad",	"Harsha",	"Ramu",	"Lalith",	"Mohit"];
		var getnames='';
		var occupation=["Actor- Puppeteer",	"Actuary",	"Administrative Worker",	"Advertising Manager",	"Aerial Rigger",	"Agricultural Adviser ",	"Agricultural Machinery Mechanic ",	"Agronomist",	"Air Traffic Controller",	"Air Traffic Safety Technician",	"Aircraft Instrument Technician",	"Aircraft Mechanic",	"Airline Clerk ",	"Ammunition And Explosives Operative ",	"Animal Technician",	"Animator",	"Anthropologist",	"Applications Manager ",	"Apprentice Training Officer",	"Archeologist",	"Architect",	"Architectural Conservation Officer",	"Art Critic And Historian",	"Art Glazier And Window-Pane Maker ",	"Art Metalworker ",	"Art Photographer",	"Art Restorer",	"Articled Clerk - Legal Assistant",	"Artificial Flower Maker",	"Artistic Promotions Manager",	"Assessor ",	"Assistant Housekeeper ",	"Assistant Printing Worker",	"Astrologer",	"Astronomer",	"Athlete ",	"Auctioneer",	"Audio Graphic Designer",	"Auditor",	"Auto-Electrician",	"Auxiliary Shop Assistant ",	"Auxiliary Worker In Geological Survey ",	"Auxiliary Worker In Textile And Clothing Industry ",	"Auxiliary Worker In The Timber Industry ",	"Auxiliary Worker In Water Management ",	"Auxiliaryworker In Pharmaceutical And Medical Production",	"Baker",	"Bank Clerk ",	"Bank Clerk For Commercial Credit",	"Banking Expert",	"Barber And Hairdresser ",	"Barman",	"Basket-Maker And Weaver",	"Beautician ",	"Beekeeper",	"Bibliographer",	"Biochemist",	"Biologist",	"Biotechnologist",	"Biscuit Maker",	"Blacksmith ",	"Blasters Foreman",	"Blast-Furnaceman",	"Blasting Works Engineer",	"Boatman",	"Boiler Operator ",	"Boilermaker",	"Bookbinder",	"Bookkeeper",	"Bookmaker",	"Botanist",	"Brewer And Maltster",	"Bricklayer",	"Broadcaster",	"Brush-Maker ",	"Builders' Labourer ",	"Building And Road Machinery Mechanic",	"Building Electrician",	"Building Fitter ",	"Building Inspector",	"Building Machine Operator",	"Building Materials Production Operative",	"Building Tinsmith",	"Building",	"Butcher And Sausage-Maker",	"Butler",	"Button Maker",	"Cab",	"Cabinet Maker",	"Cable Car Driver",	"Cable Manufacture Labourer ",	"Camera Mechanic",	"Camera Operator ",	"Canning Worker ",	"Capital Markets Clerk",	"Captain Of An Aircraft",	"Car Mechanic",	"Car Service Worker ",	"Care Assistant- Home Care Assistant- Home Care Organiser",	"Career Diplomat",	"Career Guidance Counsellor ",	"Caretaker",	"Carpenter",	"Cartographer",	"Cellulose Operator",	"Ceramic Model Maker",	"Ceramic Painter ",	"Ceramicist ",	"Ceramics",	"Charter Agent ",	"Cheese Maker",	"Chemical Industries Operative ",	"Chemical Industry Production Manager",	"Chemical Laboratory Technician ",	"Chemical Plant Machine Operator In Non-Ferrous Metal Production",	"Chemical Plant Machine Operator",	"Chemical Researcher",	"Chemical Technologist",	"Chief",	"Children'S Nurse ",	"Chimney Sweep",	"Chipboard",	"Choir Master",	"Choreographer",	"Circus Artiste ",	"Cleaner",	"Clerk For Cash Or Credit Card Systems",	"Cloakroom Attendant",	"Coffee Roaster",	"Coffeehouse Keeper ",	"Commentator- Reporter- Journalist ",	"Commercial Lawyer",	"Company Lawyer",	"Composer",	"Computer Engineer ",	"Computer Equipment Operator ",	"Computer Network Manager",	"Computer Programmer ",	"Concrete Worker ",	"Conductor ",	"Conductor ",	"Confectioner ",	"Conservator ",	"Construction Carpenter",	"Construction Site Manager",	"Cook",	"Corrosion Control Fitter",	"Court Executive Officer ",	"Craft Ceramicist",	"Craft Gilder",	"Craft Glass Etcher",	"Craft Glassmaker",	"Craft Metal Founder And Chaser",	"Craft Metalworker And Brazier",	"Craft Mosaic Maker",	"Craft Plasterer",	"Craft Stonemason",	"Craft Upholsterer",	"Crane Driver ",	"Crate Maker",	"Criminal Investigator",	"Crop Treatment Operative",	"Croupier",	"Customs Officer ",	"Cutler",	"Dairy Worker ",	"Dance Teacher",	"Dancer",	"Data Transfer Appliance Technician",	"Debt Collector",	"Decorator-Paperhanger ",	"Dental Surgery Assistant ",	"Dental Technician",	"Dentist ",	"Developing And Printing Technician ",	"Dietician",	"Digger",	"Director ",	"Disc Jockey",	"Dish Washer",	"Dispatch Clerk",	"Dispatcher ",	"Dispatcher- Electric Power",	"Diver",	"Dog Trainer",	"Doorkeeper- Porter ",	"Draughtsperson ",	"Dresser",	"Driller",	"Drilling Rig Operator ",	"Driver Of Motor Vehicles ",	"Driver'S Mate ",	"Driving Instructor",	"Dust Control Technician",	"Ecologist ",	"Economist ",	"Editor ",	"Educational Methods Specialist",	"Electrical And Power Systems Design Engineer",	"Electrical Equipment Design Engineer ",	"Electrical Equipment Inspector",	"Electrical Fitter ",	"Electrician",	"Electroceramic Production Operative",	"Electronic Equipment Mechanic ",	"Electroplating Operator ",	"Employment Agent ",	"Enamel Worker",	"Engineering Fitter ",	"Engineering Maintenance Technician ",	"Entertainment Officer",	"Environmental Protection Inspector ",	"Ergonomist",	"Ethnographer",	"Exhibitions Production Manager",	"Faith Healer",	"Farm Worker",	"Farmer",	"Fashion Designer",	"Feed Production Operator",	"Film Critic",	"Film Designer ",	"Film Or Videotape Editor",	"Film Projectionist",	"Financial Analyst",	"Financial Officer",	"Fine Artist",	"Fire Officer",	"Fire Officer ",	"Fire Prevention Officer- Fire Inspector",	"Fish Farmer",	"Fish Warden ",	"Fisherman",	"Fitter ",	"Fitter Of ",	"Fitter Of Gas Pipelines ",	"Fitter Of Steel Structures",	"Flight Attendant ",	"Flight Engineer",	"Floor Fitter ",	"Flower- Shrub Or Plant Grower",	"Flying Instructor",	"Food Industry Production Manager",	"Food Industry Technologist",	"Foreign Exchange Clerk",	"Foreign Exchange Teller",	"Forester ",	"Forest Manager",	"Forestry Machine Operator",	"Forestry Worker",	"Fortune Teller",	"Foster Parent",	"Foundry Worker",	"Fringe",	"Fruit Farmer ",	"Funeral Service Assistant ",	"Fur Coat Seamstress ",	"Furnace Operator",	"Furrier",	"Gardener ",	"Gas Industry Inspector",	"General Labourer - Chemical Industry ",	"General Labourer - Rubber And Plastic Manufacture ",	"General Labourer In Petroleum Refineries ",	"Geneticist",	"Geographer",	"Geological Surveying Equipment Mechanic",	"Geologist",	"Geomechanic Technician ",	"Geophysicist",	"Glass Decorator ",	"Glass Jewellery Maker",	"Glass Making Machine Operator",	"Glass Melter",	"Glass Painter",	"Glass Production Worker ",	"Glasscutter ",	"Glassworker ",	"Glazier",	"Goldsmith",	"Government Licensing Officials ",	"Graphic Designer ",	"Gravedigger",	"Guide",	"Gunsmith",	"Hand Embroiderer",	"Hand Lacemaker",	"Harbour Guard",	"Hardener",	"Harpooner",	"Hatter ",	"Heating And Ventilating Fitter ",	"Heating Engineer ",	"Herbalist",	"High-Rise Work Specialist ",	"Historian",	"Historical Monuments Administrator ",	"Horse Breeder ",	"Host ",	"Hotel Porter",	"Hotel Receptionist ",	"Hydrologist",	"Ice-Cream Maker",	"Image Consultant",	"Industrial Designer ",	"Information Assistant Officer",	"Information Assistant Receptionist",	"Inspector Of Telecommunications Equipment ",	"Insulation Worker ",	"Insurance Clerk",	"Insurance Sales Person- Collector- And Insurance Underwriter",	"Interior Designer Interior Designer",	"Interpreter And Translator",	"Investment Clerk",	"Invoice Clerk",	"Jeweller ",	"Jewellery Maker",	"Joiner And Cabinetmaker ",	"Judge",	"Keeper Of Records ",	"Keeper Of Service Animals",	"Knitter",	"Land Surveyor",	"Landscape Architect",	"Laundry Worker & Dry-Cleaner ",	"Laundry Worker ",	"Lecturer ",	"Lecturer In Vocational Courses",	"Lecturer - Research",	"Librarian ",	"Lifeguard ",	"Lift Attendant",	"Lift Fitter",	"Lighting Technician",	"Lightning Conductor Fitter ",	"Lithographer",	"Livestock Farmer",	"Lottery Ticket Street Vendor",	"Machine Shop Worker ",	"Machinery Inspector",	"Maker Of Non-Woven Textiles",	"Make-Up Artist And Wigmaker",	"Management Accountant",	"Management Consultant",	"Manager",	"Marine Engineer ",	"Marine Hotel Manager",	"Marketing Manager",	"Masseur",	"Master Of Ceremonies",	"Materials Handler",	"Mathematician",	"Medical Laboratory Assistant ",	"Mechanic - Measuring- Controlling And Automated Systems ",	"Mechanic ",	"Mechanical Engineering Designer",	"Mechanical Engineering Production Manager",	"Mechanical Engineering Technologist",	"Mechatronic Engineer",	"Metal Engraver",	"Metal Grinder",	"Metal Refiner",	"Metal Turner",	"Metal Worker ",	"Metallurgist ",	"Metallurgist Of Nonferrous Metals",	"Meteorologist",	"Metrologist",	"Microbiologist",	"Midwife",	"Miller",	"Milling-Machine Operator",	"Mine Rescue Service Mechanic",	"Mine Ventilation Technician ",	"Miner",	"Mining Air Control Technician",	"Mining Electrician - Heavy-Current Equipment ",	"Mining Finisher ",	"Mining Machine Operator",	"Mining Mechanic ",	"Mining Rescue Worker ",	"Mining",	"Model",	"Modeller ",	"Motor Vehicle Bodybuilder",	"Mountain Guide",	"Multimedia Designer",	"Multimedia Programmer ",	"Municipal Police Officer ",	"Municipal Services Worker ",	"Municipal Street Cleaner ",	"Museum Curator",	"Music Director",	"Musical Instrument Mechanic ",	"Musician",	"Musicologist",	"Nanny ",	"Naturalist",	"Newspaper Editor",	"Nuclear Power Station Operator",	"Nurse ",	"Nursery School Teacher ",	"Nutritionist",	"Office Junior",	"On-Line Customer Services Operator",	"Operational Analyst",	"Operations Electrician For Heavy-Current Equipment ",	"Operations Mechanic ",	"Operative - Food Processing ",	"Operative In Chemical And Synthetic Fibre Manufacture",	"Operator In The Tobacco Industry",	"Operator Of Gas Plant Equipment ",	"Operator Of Numerically Controlled Machine Tools",	"Operator Of Plastic Material Processing Machines ",	"Optical Component Maker ",	"Optical Instrument Mechanic",	"Ore Crusher ",	"Orthopaedic Shoemaker ",	"Orthotic",	"Orthotist",	"Out-Of-School Educator",	"Overhead Telecommunications Cable Fitter",	"Packer",	"Paediatrician",	"Palmists",	"Paper Worker",	"Paramedic ",	"Patent Agent",	"Paver - Asphalt Layer ",	"Pawnbroker",	"Pedicurist- Manicurist ",	"Personnel Officer",	"Pest Control Officer",	"Petroleum And Petrochemical Process Operators",	"Pharmaceutical Industry Operative ",	"Pharmaceutical Laboratory Technician ",	"Pharmacist",	"Philosopher",	"Photographer",	"Photographic Reporter ",	"Physicist",	"Physiotherapist",	"Piano Tuner",	"Pilot ",	"Pilot[Aircraft]",	"Pipe Fitter",	"Pipe Fitter",	"Pizza Maker",	"Plumber",	"Plywood Maker",	"Police Assistant ",	"Police Investigator ",	"Police Officer",	"Political Scientist",	"Pollster",	"Post Office Counter Clerk",	"Postal Service Worker",	"Postal Transport Worker",	"Postal Worker ",	"Postmaster/mistress",	"Poultry Breeder ",	"Poultry Butcher ",	"Powder Metallurgist",	"Power Engineering Specialist",	"Power Station Supervisor",	"Power Station Operator",	"Power System Worker ",	"Power Truck Driver",	"Prefab Construction Worker",	"Press Officer",	"Pricing Officer",	"Priest",	"Primary School Teacher",	"Printer",	"Printing Machine Mechanic",	"Printing Technician",	"Prison Guard ",	"Private Detective",	"Producer",	"Producer Of Leather Goods",	"Product Designer ",	"Production Manager ",	"Production Manager In Glass And Ceramics",	"Production Manager In Textile Industry",	"Production Manager In Wood Industry",	"Production Technologist ",	"Professional Soldier",	"Prompter",	"Property Manager",	"Props Master ",	"Psychiatrist",	"Psychologist",	"Psychotherapist",	"Public Administration Officer",	"Public Notary",	"Public Relations Manager",	"Publican ",	"Publisher",	"Purchasing Officer",	"Quality Control Technician ",	"Quality Inspector",	"Radio And Tv Technician",	"Radio And Tv Transmission Engineering Technician",	"Radio Officer",	"Radiographer",	"Rail Transport Worker",	"Rail Vehicle Mechanic",	"Railway Carriage And Wagon Inspector",	"Railway Electrician ",	"Railway Engine Mechanic",	"Railway Freight Handler",	"Railway Guard ",	"Railway Operative ",	"Railway Booking Office Clerk",	"Railway Track Construction Fitter",	"Railway Yard Worker",	"Real Estate Agent ",	"Referee ",	"Refrigeration Engineer ",	"Refuse Collector",	"Registrar",	"Furniture Removal Worker ",	"Reproduction Technician",	"Restorer Of Applied Arts And Crafts",	"Retoucher",	"River Basin Keeper ",	"Road Sign Assistant ",	"Road Transport Technician",	"Rolling-Mill Operator ",	"Roofer ",	"Room Maid ",	"Rope Maker",	"Rotating Machine Fitter",	"Rubber Operator ",	" Tyrefitter",	"Safety And Communication Electrician",	"Safety Engineer",	"Safety- Health And Quality Inspectors- Health And Safety Inspectors",	"Sales Assistant ",	"Sales Manager",	"Sales Representative ",	"Scaffolder",	"Scene Painter",	"Scene-Shifter",	"Script Editor",	"Script Writer ",	"Sculptor",	"Seaworker",	"Secondary School Teacher",	"Secretary ",	"Section Supervisor ",	"Security Guard",	"Service Mechanic",	"Sewerage System Cleaning Operator ",	"Sewing Machinist",	"Shepherd- Goatherd",	"Shift Engineer",	"Ship Fitter ",	"Ship'S Captain",	"Ship'S Officer",	"Shoemaker ",	"Shop Cashier ",	"Shunter",	"Shunting Team Manager",	"School Caretaker",	"School Inspector",	"Silkworm Breeder- Sericulturist",	"Singer",	"Smith",	"Social Worker",	"Sociologist",	"Solicitor",	"Songwriter",	"Sound Effects Technician",	"Sound Engineer",	"Spa Resort Attendant ",	"Special Educational Needs Teacher",	"Special Effects Engineer ",	"Special Needs Teacher ",	"Specialist In Animal Husbandry ",	"Spectacle Frame Maker",	"Speech Therapist",	"Spinner",	"Stable Hand- Groom",	"Stage Costume Maker",	"Stage Designer ",	"Stage Manager",	"Standards Engineer",	"State Attorney ",	"Station Manager",	"Statistician",	"Stockbroker",	"Stonemason- Stonecutter ",	"Storekeeper ",	"Stove Fitter",	"Stuntman ",	"Sugar-Maker ",	"Surgical Toolmaker ",	"Surveyor'S Assistant",	"Sweet Factory Worker ",	"Systems Designer ",	"Systems Engineer ",	"Tailor- Dressmaker ",	"Tamer ",	"Tanner",	"Tannery Worker",	"Tax Specialist- Tax Adviser",	"Technical Editor",	"Technologist In Glass And Ceramics",	"Telecommunications Cable Fitter",	"Telecommunications Dispatcher ",	"Telecommunications Engineer",	"Telecommunications Installation And Repair Technician",	"Telecommunications Mechanic ",	"Telecommunications Technician",	"Telecommunications Worker",	"Telephone Operator",	"Teller",	"Textile Printer",	"Textile Refiner",	"Textile Technologist",	"Textiles Dyer",	"The Doctor ",	"The Hygiene Service Assistant ",	"The Medical Orderly ",	"The Optician ",	"Ticket Collector",	"Tinsmith",	"Tobacco Technologist",	"Tool Setter ",	"Tool-Maker ",	"Town Planner",	"Track Engineer",	"Tracklayer",	"Tractor-Driver",	"Trading Standards Officer",	"Traffic Police Officer ",	"Train Dispatcher",	"Train Driver ",	"Trainee",	"Trainer ",	"Tram Driver",	"Transport Supervisor ",	"Travel Agency Clerk",	"Travel Courier ",	"Tunneller ",	"Tutor",	"Typesetter",	"Underground Mine Safety Engineer ",	"Upholsterer And Decorator ",	"Usher (ette)",	"Valuer",	"Varnisher ",	"Veterinary Surgeon",	"Veterinary Technician ",	"Viniculturist ",	"Wages Clerk",	"Waiter ",	"Wardrobe Master (Mistress)",	"Warehouse Clerk",	"Waste Incineration Plant Worker",	"Water Management Controller ",	"Water Supply And Distribution Equipment Operator",	"Water Treatment Plant Operator ",	"Watercourse Manager ",	"Watch-Maker ",	"Guard",	"Weaver",	"Weaver ",	"Weigher",	"Weir And Dam Operator",	"Welding Operator ",	"Well Digger",	"Whaler",	"Window Cleaner",	"Window-Dresser",	"Wine Maker",	"Wire-Drawer",	"Wood Carver",	"Wood Industry Technologist",	"Woodcutting Manager",	"Woodworking Operator ",	"Work Study Engineer",	"Worker In Electrical Engineering Production",	"Worker In Gas Distribution",	"Worker In Pressing And Stamping Shops",	"Worker In Recycling Services ",	"Worker In Shoe Production ",	"Worker In The Food Industry ",	"Worker In The Paper Industry",	"Worker In The Production Of Building Materials",	"Worker The In Fur Processing Industry",	"Worker- Metal Industry ",	"Zookeeper"];
		$.ajax({
			url: 'https://randomuser.me/API/?nat=us&results='+noofrowsSelected+'&inc=name,gender,dob,phone,email,location,id',
			dataType: 'json',
			success: function(data) {
			getnames=data;
			console.log("<<<<response::data>>>",data);
			var randomnames=[];
			var getgenders=[];
			var getages=[];
			var getphones=[];
			var getcity=[];
			var getstate=[];
			var getpostcode=[];
			var getemails=[];
			var getcoordinates=[];
			var getaddress=[];
			var getssn=[];
			var getBloodGroup=["A+","A-","B+","B-","O+","O-","AB","AB-"];
			var getRandomBloodGroup=[];
			var getRandomOccupation=[];
			var getRandomAlphaNumeric=[];
			var getWeights=[];
			var ZodiacSigns=["Aries",	"Taurus",	"Gemini",	"Cancer",	"Leo",	"Virgo",	"Libra",	"Scorpio",	"Ophiuchus",	"Sagittarius",	"Capricorn",	"Aquarius",	"Pisces",	"Cetus"];
			var getZodiacSign=[];
			var getPanNumbers=[];
			var getCharacters=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];
			var getCreditCards=["4539899668423140",	"344721827929833",	"3528654075939260",	"3096192234485700",	"4916805204597340",	"5563716252936770",	"3112893156553540",	"3112257641886620",	"4532734545761290",	"3337025828284740",	"342727289710134",	"4485004201582820",	"5231724595895880",	"5110516146798610",	"3528089988926050",	"4024007171183180",	"5521762115699440",	"342228503742813",	"4520580403446850",	"4539075869361140",	"377373386608034",	"341570229447933",	"4794186413616040",	"5499177651479050",	"5370511783606710",	"3528624938220310",	"3112009913674970",	"5149090784383160",	"4539958484601920",	"3096894404647430",	"5244578566898890",	"4113300817884140",	"3158467745237700",	"4701611313295200",	"4556570917481550",	"3337351407099750",	"5485956640224350",	"341049136586059",	"4556086394257550",	"4024007131768370",	"344655048084244",	"4485366113634260",	"3112865483834110",	"4207297559685890",	"4929117321096220",	"3112770348044910",	"4556309180866980",	"3088889878438180",	"4929061824059280",	"343554923771523",	"379368597123631",	"5285249814413740",	"3158040932315400",	"3528511057169190",	"5129443793147340",	"340465286781384",	"5213140525070740",	"3337127572853970",	"4916204806395490",	"379256520249740",	"347848878074750",	"3088432914196980",	"4848901771409190",	"4716832626525570",	"4539288285034870",	"4539554170822400",	"3528257744345130",	"5571948747462210",	"4539337956669660",	"348394513946598",	"342752305261078",	"4529939031586240",	"373261584678533",	"341121636017990",	"379391329362368",	"3088669100181540",	"4556742736017680",	"342286637003759",	"343394478589305",	"5461038416292880",	"5177396507545420",	"370828841196914",	"5512843217213790",	"4469016342214020",	"5197839624487460",	"371774668348312",	"4903082130525410",	"349152669359969",	"4485767771751110",	"3528316298917780",	"3337947815952060",	"4929966466175000",	"371054332071123",	"3112796287813380",	"3112843223601910",	"4532724795343330",	"4539630014442410",	"5491264240064180",	"5134164774363590",	"343180856272667",	"5220434022697930",	"4716622540200230",	"3096285887844740",	"5495607140057620",	"5278778702672620",	"4961622227286210",	"4716435753010930",	"3088630738818380",	"4716770312940000",	"4532969480664540",	"4532630312682940",	"344503110765474",	"378185072948345",	"3112013192369110",	"370547100380247",	"5226184210526290",	"3088809053090430",	"3337134588112610",	"5565674383316980",	"3088503872765980",	"5461115050499740",	"4539058974802760",	"4958516643867310",	"376607758576035",	"4556071535758790",	"5362817690579740",	"5272783813658380",	"4024007116808160",	"5339811342751610",	"5230905083252930",	"3158094686128220",	"3158375400829710",	"5295427698809430",	"4024007138076030",	"344315924460139",	"3528872461857900",	"5111837817354530",	"4556532539282290",	"5404292476694580",	"3096160916655580",	"4532228371065390",	"5284850868375730",	"4716716687458870",	"3096854827076470",	"4485247360758680",	"5485626460876780",	"3088888567018890",	"5126040095842060",	"5572885319183160",	"341675774856493",	"374815484025100",	"3096905282144400",	"3096717792388460",	"374176764219297",	"3088026834736960",	"370325955910669",	"3337744982709540",	"5167293074464180",	"4212767415775760",	"5138984397462830",	"5382765023891980",	"375972015674119",	"349030304671073",	"4716253306247870",	"5131530505644770",	"5349593482487760",	"5231728244738050",	"4024007152369870",	"5381729733511510",	"4929559975372890",	"5555312436569520",	"4746437748250840",	"375281713000449",	"5585147636757030",	"340655869509547",	"4716124530426980",	"3158565789284740",	"4916417272685430",	"3337731329494720",	"4929669908708260",	"5537046893654120",	"371057435481248",	"3158509025537050",	"4485423041763170",	"5533875592754030",	"374223559583006",	"3112401831186390",	"374946103079291",	"3096711578484280",	"372255932162837",	"3112611304911990",	"4539380818931280",	"5529838207189360",	"377957312303379",	"4556123148604730",	"340982334915525",	"3158567503687960",	"340084406855026",	"5344549227201180",	"3528847327228920",	"4556836979501200",	"374983679651575",	"3096386037288120",	"5426535949505560",	"5322653861878640",	"378130395075657",	"5420436703776730",	"4929194717023650",	"5112062325363490",	"3158410172226610",	"375303850155362",	"343892489933024",	"5209555342847180",	"3337804956455440",	"340434404892424",	"5118322658096440",	"5294332509963190",	"3528461158660530",	"4716485777819190",	"5319715389821400",	"5450270378065470",	"5518680185741170",	"5543276327893270",	"4556790123009570",	"372653107707347",	"5327208753270410",	"5236845890231250",	"3337324177503950",	"3158791911500580",	"5119835354383320",	"4018785617028070",	"4556413216728000",	"5324322370119940",	"3096454213158870",	"3158059063632230",	"5559466359136690",	"5474002989864500",	"3158916100230620",	"3096597154232570",	"345703451468873",	"3158188204376650",	"3528272606258150",	"3096466481944960",	"3088021820132850",	"5392427335300920",	"4716306815495390",	"4716638314374740",	"3096935937865810",	"372054002085873",	"3528031381979850",	"5203952424013890",	"4024007152969630",	"3088781030894010",	"4539469375918510",	"3528411313683900",	"3112723777630430",	"344167129254522",	"4539471401415080",	"3088738520990360",	"3096389555694990",	"3337917179155380",	"377441040738271",	"3158977380168450",	"4367223475059980",	"4716732646924980",	"4024007179805340",	"3337718698349650",	"4556978664810270",	"4929318712975620",	"3112977303091090",	"3528033838327600",	"3528219951780710",	"5117691568878420",	"4539358226441200",	"373281642146398",	"344027832846057",	"373939858537804",	"371234199707700",	"3528983137507420",	"4539016241078450",	"4532761847478420",	"3096174331945370",	"374814506123340",	"5468826036927740",	"342215800935562",	"5140656032193950",	"345296078093604",	"3337719226051960",	"4991601034836210",	"3528475852880790",	"4485046916969300",	"371105606650818",	"5126790890331920",	"3096485028150490",	"378689433849365",	"4532573181487380",	"5295895285662510",	"4916161249039350",	"4532838656179680",	"3096394715614530",	"5536444736806140",	"5422477073677740",	"4532373557780640",	"4929594784032130",	"5274377616219470",	"370081796348623",	"5331780473991380",	"3337526934935080",	"344694072407815",	"3158461858080760",	"349121734032075",	"5109903514790860",	"5169957568441310",	"343251904397556",	"373721914722038",	"4667054226150650",	"5162705931083890",	"3337367524609300",	"5455397831761220",	"3337401587693740",	"3112070371452620",	"349694009481698",	"4929475214164330",	"376046017182501",	"4556207982858150",	"371315989147353",	"4929031902943280",	"4539735423233310",	"372257198100048",	"4556663571276030",	"377847187877955",	"372210706691008",	"5425287298689870",	"5141540734719010",	"5290398895095590",	"3088525082659690",	"345877016515574",	"340710154911385",	"374076624435440",	"3088773546224400",	"3096298802436920",	"3096229347312120",	"347891258078231",	"3088251538197870",	"5341284865028440",	"3337019284202700",	"377873039808287",	"342740888459102",	"4539068211987930",	"3337735965542100",	"5488668693908660",	"4024007187904400",	"376925870459157",	"345884232597022",	"3337729176459810",	"376693859591008",	"3337296091876010",	"342435947345943",	"4485394210798230",	"3096538813602660",	"4929916280613120",	"4556684322740590",	"370898811666667",	"4930736980392880",	"3158008674003670",	"4532557824485250",	"4916303898968670",	"3337815564261120",	"4716938832080990",	"3112694346749270",	"349680215436329",	"4532571005078540",	"3528374171580620",	"5583866335013350",	"5515139339167570",	"4022782648281410",	"4485624637721070",	"379958605002775",	"5403475249384430",	"5292823691732910",	"343123552359164",	"3088409696430260",	"4532377044840840",	"3088561868970360",	"5148329083751530",	"4556659424388490",	"4485356106665930",	"4069858663123040",	"4024007167900920",	"340378642473465",	"3158686224152220",	"4548431657882580",	"345494159921518",	"5558532263931310",	"346372735214229",	"3528380182498660",	"4024007163037810",	"5442370983438460",	"5320242026914680",	"373585451693765",	"3158554407409970",	"4789669343179950",	"3528182147540970",	"3096945899956020",	"3112347709180200",	"4539663108159970",	"3096335655044250",	"348189908764295",	"371693134155194",	"3112645294205460",	"3528137560126920",	"4716229167990080",	"375275113256320",	"3528221526444230",	"3112014065489640",	"3112051104468660",	"5554256517805910",	"342425515171235",	"349399995797335",	"3158162771372620",	"379854324418592",	"5304986525463790",	"3096977737097600",	"340525838352065",	"4485773681297560",	"5487000569396380",	"344698051321046",	"4716366707471050",	"4916598226898450",	"5407388803524790",	"4074441215964780",	"345302518744523",	"344954185705020",	"5530166130939850",	"5587345536629970",	"342497930677740",	"5392829307169410",	"4556856637356380",	"5524122933753290",	"3158540331306990",	"370639933463769",	"3528331608910990",	"3112314384959710",	"348003385820282",	"3158143438343470",	"4916025832406540",	"378526866457664",	"3528914550679340",	"4929632125609300",	"370981367913384",	"5529415912391950",	"345616292549059",	"4532121015672490",	"374520266488720",	"5131292668243160",	"4485733698276160",	"3088702137718990",	"5137099058265450",	"3528087263447040",	"5109371917958440",	"4556492699913130",	"3158200774298970",	"375896254845868",	"4539109039614660",	"4716065601062310",	"343851360841938",	"4000800582376420",	"3088956282675020",	"375282891515778",	"5330857987761470",	"371330598569996",	"376562957622355",	"5268557053262650",	"4929048688880560",	"3528898764528730",	"344707173505343",	"3528262307982030",	"5291075677020430",	"3337999253873170",	"5190329086517700",	"5545387858241190",	"5137129620530620",	"342182909113253",	"3096026268890390",	"5567734047922750",	"3088787260460800",	"5549796618558400",	"4916766062565940",	"5550850488565870",	"5311163146718500",	"3337605072294570",	"375257724882058",	"345408487167263",	"4556791451875780",	"4929185005134440",	"5252750431764890",	"3158633885933510",	"3337337066775400",	"4485860169286290",	"4916004109775640",	"374227871968175",	"374355759842962",	"340434448938605",	"376750728402005",	"344269687381232",	"4023298591654090",	"3528580188123530",	"5529201622964890",	"346041477733213",	"5340232775480160",	"4539297924578870",	"5163009231014720",	"4539807153292760",	"5557262540836800",	"4556275486902470",	"4532179391697860",	"372432080329134",	"4532417822209660",	"4556310855617970",	"3096278327644910",	"373886367773463",	"347926192134714",	"3158502243524050",	"4929744397510590",	"5323874142748590",	"5405721215235770",	"4929764273524800",	"341600104170852",	"3528267946749770",	"4097648778503760",	"344891763594196",	"3528844852084790",	"5233759512083060",	"4736857170250240",	"371650709876208",	"5515578077980570",	"5446512039128990",	"3112437639098830",	"4532662015040470",	"3112816977264410",	"3112298241251100",	"4916612333365940",	"5246351544931940",	"4716003595416830",	"346338044936620",	"4556873309237490",	"4532064359540140",	"4916159722523280",	"4716996197130280",	"5575949816954880",	"5163745700175010",	"3337630977870350",	"3337820209727090",	"370707754041988",	"3096530241280310",	"5289562909748910",	"372866719917639",	"5405523836917820",	"340171985064300",	"5505727378936710",	"371234896082720",	"5120249417879100",	"349562524127718",	"3088913454173470",	"4716852411148900",	"3528691881760190",	"3158749585051950",	"340268651567812",	"371795404006179",	"5303004358754750",	"5200604420366110",	"3158680571253130",	"4539446132323950",	"341540477749439",	"346136828057377",	"5442915879163530",	"4916023631603750",	"372400806117786",	"374831517420952",	"5190333291865640",	"3096744660457640",	"5202225373378390",	"5110915152728630",	"4695143651511480",	"374823996007764",	"4485327076704300",	"3337836869906790",	"5358923572901200",	"370068892357491",	"372554302623729",	"347853358850729",	"5501869041669130",	"345256889046381",	"3528863982612780",	"5173438245739400",	"5107881444679720",	"4829429611103140",	"4916807324001990",	"4024007104274340",	"3112575676429810",	"4916281809968040",	"3096915534967370",	"5245694396345650",	"4539944154227690",	"5242041486966240",	"4024007177665400",	"5206917354007230",	"4532647458364350",	"3528648580030120",	"5467045603677950",	"345213244762384",	"5568780744775010",	"372830859069221",	"370582021913982",	"4532787388038580",	"4485801796297750",	"4716597609297790",	"4532597620285710",	"4539239200874830",	"343624034938681",	"5568145185379110",	"5317948432991210",	"5556487975796840",	"3158604094121470",	"3088121871091270",	"346184733012178",	"4694052923239960",	"5564401712502390",	"4716820032525410",	"4539164344051840",	"340929930303994",	"5262849403522070",	"378617340778377",	"4716937029168410",	"346961049507748",	"4532523113456080",	"4929575721918470",	"5349129410208660",	"5159017186925640",	"5579522849806870",	"4916969940389310",	"343405461232404",	"3337460966905840",	"5211914524763920",	"347216607789587",	"4716089691959590",	"3337859811493760",	"4916708025300460",	"5310965845104890",	"3337193321783790",	"3088481029093510",	"348043763865509",	"5521290776702460",	"3088634525494830",	"373464659121153",	"5365809843431730",	"3337603807557340",	"3112538209101760",	"5592860778857340",	"370606319695892",	"3088655419424510",	"379767579932861",	"341398123351633",	"375310737086694",	"4556773412406450",	"5448899621266420",	"5220415897608460",	"5421502096431340",	"375461211916318",	"5316659059270080",	"340293591773262",	"372913676084522",	"5424470499702240",	"343123144141393",	"4556744248799700",	"5289641269451950",	"5594397169848740",	"342364280131753",	"3528282054504670",	"3088030488203150",	"4024007112649790",	"4485033775437900",	"4485466122572430",	"5182409720477480",	"4485629783694560",	"341232495705359",	"378534433180660",	"370150752493937",	"5111134729694760",	"346329093081459",	"378474477998166",	"3158628050302510",	"373626189052468",	"3088629720745480",	"341452818379514",	"377980640895775",	"3096418930946460",	"3096691403449850",	"342124542268805",	"341934035849239",	"3088573043099170",	"3088894731134400",	"342527821603676",	"5584185110636020",	"378439997054683",	"3096899868129680",	"5101395113140420",	"4929256755013420",	"5540254936100670",	"373808381781033",	"4716772048046310",	"3096980625710470",	"3158549388152910",	"3528097208273400",	"4929283526947340",	"370865515046934",	"3088035700741140",	"5434508978862360",	"4024007117003520",	"3158807174267910",	"3088170511051220",	"3337644643761810",	"5531171075158730",	"5450898086548000",	"374738491454933",	"3112201428098110",	"340055718843751",	"5103022034009680",	"5498609883824160",	"341015973315951",	"4929981754617410",	"3528943824752700",	"5410629519123260",	"342549384193523",	"3088282505029480",	"349712819388463",	"373982388292102",	"347910478936158",	"5272765957658100",	"379948061098763",	"5548334519660300",	"4539471637747130",	"4532754386727080",	"5509931112222460",	"5493342141331980",	"3158122150073110",	"3112908923234290",	"5521098340546090",	"4024007186113150",	"4716341453365880",	"5147347135726250",	"4539427940128190",	"5314372720494600",	"375973089462704",	"343052598420567",	"5162920772649210",	"377352113838155",	"5469074204415860",	"5290941468825040",	"4929118476802180",	"5439083525392510",	"5405961826314390",	"5223978426275880",	"375429909653394",	"4716181292765720",	"3337568114084820",	"375565531608288",	"5131823021035730",	"4716778448065660",	"3112563205923030",	"5407010938687720",	"5391035640434860",	"5283643488212970",	"4532289533098890",	"3112301222048530",	"3158359608405810",	"4024007193190330",	"349315888427947",	"5459808444098730",	"3096522180934910",	"5403520880411210",	"340757245498989",	"3528798325271370",	"4532918612261070",	"3337877570815280",	"340812934046514",	"378650520484375",	"3528169854127950",	"3088304344383340",	"4916516621307800",	"378560033978633",	"341931980688455",	"4929056770459120",	"5573380686515380",	"3528768982101740",	"340858734736598",	"370006906325104",	"3112911096913500",	"5315703788449720",	"4485244976871840",	"4916456351264830",	"3112329957818530",	"4539415531382600",	"5564381276999450",	"4539167222745770",	"347699020180296",	"5418976533998290",	"4929296809675130",	"372919832214184",	"5193004426790420",	"3528138270215190",	"5418877124384410",	"4916428127551320",	"375590105162793",	"4539413188411200",	"4024007170768020",	"342422231241053",	"5469065008569180",	"4067910750501180",	"3158456983556090",	"376222613417381",	"3337956410581440",	"4539477136336760",	"5467733943247070",	"376046491375340",	"4539873581808530",	"5411215948828030",	"3088244768370350",	"373152510276551",	"348847090809299",	"5227241186418100",	"4485611422942720",	"5299623215319010",	"4556037799482340",	"5208888808662450",	"4532202130698930",	"371680444131494",	"347300315908281",	"4556727618316410",	"5462279703336820",	"375242490883357",	"347569463349692",	"4556441312204810",	"5173112666595770",	"3158596690375050",	"3096158366043810",	"378727729873572",	"342071292975123",	"3112451426045420",	"4539537179895240",	"4916443141713120",	"4485676976865470",	"5378861485096980",	"4698487952584660",	"4539411841172560",	"5148516698038860",	"4485122066010050",	"3528013237209310",	"4539265024228340",	"4539872415139560",	"4929591814825920",	"3112400004473780",	"5132619335965650",	"3096586548656680",	"3096416783064820",	"378235728760840",	"5101641083001010",	"4539283043089350",	"4339426806727140",	"4556496418759420",	"345188163731703",	"3112138944024550",	"3088798764060400",	"3112353679652220",	"5423608186919200",	"4539604368473760",	"5496382673023880",	"3096528389463910",	"3528924437861160",	"5567491292512330",	"3096500781542880",	"3158740908154460",	"3528854930653950",	"4589706545778280",	"370423951290184",	"375914607837480",	"4024007142690340",	"4485658869715510",	"4539735832966450",	"4716997613988820",	"373838204415949",	"5124887222148210",	"4382291975495270",	"5465031476361810",	"5137137226405160",	"379431345062806",	"5523955950219960",	"4539090737086060",	"4485687886249360",	"5193097536431370",	"5236823174542040",	"3088473111988940",	"5547486706946280",	"4024007113956390",	"373828926350805",	"3088182405301340",	"5589827692488500",	"3112766130228400",	"3337270003030030",	"3528340953322050",	"3528715966563180",	"340103762905173",	"3158811339880400",	"5182393054947280",	"3112657764575430",	"5572662576670420",	"3158270100845810",	"344183189553034",	"349548493557225",	"5359634930264090",	"5196236142823250",	"347383998717302",	"4532039532496810",	"349777290080962",	"5592494224313930",	"346333279142655",	"3096102504109950",	"5495801231941890",	"3112314949586150",	"3337266652445010",	"4024007187739680",	"347484502994518",	"343871825990708",	"3158422146778930",	"4716538573702190",	"5116002020812000",	"340082779827135",	"5147561901944230",	"5296113427418540",	"3528006057211640",	"3112323243419900",	"378221442289324",	"374166438102151",	"3088301234332170",	"3158438323540040",	"3096773057973520",	"4916540125838700",	"4556517710312050",	"5354660231750980",	"5156008735724620",	"346414314792991",	"349215295470300",	"378771596514927",	"3158684878061430",	"3096071012812510",	"3112917751818880",	"3096324278217670",	"3337352209944320",	"372892007708027",	"5318801411052670",	"4716364906099900",	"345126341818620",	"370778282126351",	"347938822804004",	"4916712164642460",	"5232196398114930",	"348598388478632",	"5482110311002270",	"373595671660171",	"372826743243758",	"4958976486451950",	"3158368333492330",	"5547179997194480",	"375639064645288",	"3112156855640640",	"5301642516839270",	"3096151179395650",	"3337590259868470",	"3096282487461980",	"4485796236021700",	"340201599449629",	"3088918912602700",	"5374853683358710",	"5136568314601450",	"4024007184370850",	"3096498509287230",	"5347415251253850",	"3112722187427870",	"5539696426757820",	"345640112317307",	"4485747550975390",	"5363745320290790",	"5503081869987300",	"3337763471711680",	"3088861445034590",	"4420659707458010",	"5378042646537860",	"349723998756172",	"3112148867232580",	"374946463857203"];
			var getABNNumbers=["55385472835",	"55385483608",	"55385491465",	"55385491546",	"55385499559",	"55385505403",	"55385524033",	"55385524114",	"55385525890",	"55385525971",	"55385537441",	"55385540378",	"55385563587",	"55385565030",	"55385577822",	"55385577903",	"55385585760",	"55385590302",	"55385600740",	"55385600821",	"55385602473",	"55385613246",	"55385613327",	"55385618392",	"55385621184",	"55385660674",	"55385668768",	"55385671528",	"55385672144",	"55385684936",	"55385687398",	"55385687479",	"55385689035",	"55385692793",	"55385695240",	"55385701649",	"55385717342",	"55385717423",	"55385720279",	"55385724858",	"55385726220",	"55385726301",	"55385737991",	"55385743488",	"55385743569",	"55385757804",	"55385765661",	"55385765742",	"55385774571",	"55385796068",	"55385832718",	"55385837800",	"55385840575",	"55385840656",	"55385848669",	"55385852126",	"55385858163",	"55385864837",	"55385864918",	"55385891486",	"55385895984",	"55385904759",	"55385912697",	"55385914140",	"55385934870",	"55385953581",	"55385957339",	"55385963382",	"55385991214",	"55386002845",	"55386002926",	"55386010783",	"55386014315",	"55386018700",	"55386018796",	"55386018877",	"55386028290",	"55386031131",	"55386034964",	"55386039063",	"55386039144",	"55386061824",	"55386062715",	"55386069788",	"55386070572",	"55386078634",	"55386081345",	"55386081426",	"55386086491",	"55386097264",	"55386097345",	"55386115770",	"55386115851",	"55386119609",	"55386124761",	"55386138239",	"55386146177",	"55386161341",	"55386166811",	"55386169386",	"55386172114",	"55386173971",	"55386185441",	"55386185522",	"55386192957",	"55386194400",	"55386202154",	"55386202235",	"55386208191",	"55386208272",	"55386210092",	"55386211032",	"55386239905",	"55386242616",	"55386249689",	"55386250554",	"55386258535",	"55386258616",	"55386266473",	"55386276210",	"55386298592",	"55386307448",	"55386335118",	"55386341323",	"55386346712",	"55386372858",	"55386372939",	"55386380796",	"55386393319",	"55386411825",	"55386418898",	"55386419806",	"55386427744",	"55386430455",	"55386430536",	"55386439214",	"55386446374",	"55386446455",	"55386447071",	"55386459863",	"55386478493",	"55386478574",	"55386485977",	"55386498306",	"55386502383",	"55386510451",	"55386515921",	"55386518496",	"55386521224",	"55386521305",	"55386534551",	"55386534632",	"55386543510",	"55386550800",	"55386560697",	"55386560778",	"55386578302",	"55386581158",	"55386582870",	"55386582951",	"55386597013",	"55386598870",	"55386607645",	"55386607726",	"55386610275",	"55386615583",	"55386619115",	"55386627053",	"55386639764",	"55386653199",	"55386673720",	"55386675372",	"55386686145",	"55386686226",	"55386694083",	"55386721968",	"55386722471",	"55386742429",	"55386754590",	"55386761059",	"55386762933",	"55386770790",	"55386774548",	"55386778771",	"55386778852",	"55386793178",	"55386793259",	"55386797757",	"55386799200",	"55386807035",	"55386808973",	"55386819746",	"55386819827",	"55386827684",	"55386830606",	"55386847416",	"55386853702",	"55386853798",	"55386855354",	"55386930268",	"55386946042",	"55386946123",	"55386947980",	"55386955146",	"55386959450",	"55386962387",	"55386977658",	"55386981098",	"55386985596",	"55386998119",	"55387011506",	"55387017543",	"55387017624",	"55387025481",	"55387044192",	"55387050834",	"55387066898",	"55387066979",	"55387075744",	"55387075825",	"55387083682",	"55387095152",	"55387100395",	"55387104008",	"55387108489",	"55387116250",	"55387116719",	"55387139928",	"55387143287",	"55387143368",	"55387147866",	"55387152327",	"55387163921",	"55387168246",	"55387171038",	"55387179019",	"55387188750",	"55387191510",	"55387205382",	"55387205463",	"55387242011",	"55387244953",	"55387256423",	"55387263583",	"55387263664",	"55387275053",	"55387275134",	"55387284012",	"55387287926",	"55387295783",	"55387304558",	"55387304639",	"55387327767",	"55387327848",	"55387338459",	"55387340166",	"55387343903",	"55387348228",	"55387349940",	"55387351841",	"55387356085",	"55387399058",	"55387419120",	"55387424854",	"55387424935",	"55387436405",	"55387453140",	"55387454031",	"55387475684",	"55387484724",	"55387500384",	"55387501437",	"55387517356",	"55387520067",	"55387520148",	"55387537860",	"55387540620",	"55387540701",	"55387568186",	"55387583350",	"55387594123",	"55387594204",	"55387595980",	"55387604836",	"55387605533",	"55387612693",	"55387612774",	"55387616306",	"55387624163",	"55387624244",	"55387633122",	"55387644893",	"55387664625",	"55387664706",	"55387670830",	"55387672563",	"55387688482",	"55387691274",	"55387700951",	"55387705195",	"55387729457",	"55387748087",	"55387748168",	"55387757127",	"55387768721",	"55387768802",	"55387782043",	"55387790369",	"55387794948",	"55387795370",	"55387796310",	"55387804145",	"55387804226",	"55387812083",	"55387813104",	"55387833834",	"55387845255",	"55387849753",	"55387850989",	"55387852464",	"55387852545",	"55387868383",	"55387868464",	"55387909358",	"55387909439",	"55387917183",	"55387917296",	"55387924603",	"55387937109",	"55387937930",	"55387943233",	"55387943314",	"55387948703",	"55387951090",	"55387956641",	"55387974849",	"55387982787",	"55388003961",	"55388014734",	"55388014815",	"55388018023",	"55388019880",	"55388022591",	"55388022672",	"55388038591",	"55388049639",	"55388068269",	"55388072935",	"55388080792",	"55388080873",	"55388084405",	"55388088967",	"55388092343",	"55388098380",	"55388105503",	"55388105599",	"55388107236",	"55388113360",	"55388113441",	"55388115093",	"55388118911",	"55388121767",	"55388121848",	"55388144976",	"55388173294",	"55388173311",	"55388184148",	"55388197556",	"55388201682",	"55388202573",	"55388202654",	"55388214269",	"55388237478",	"55388253614",	"55388256189",	"55388259651",	"55388260774",	"55388260855",	"55388261471",	"55388272244",	"55388272325",	"55388278281",	"55388278362",	"55388280182",	"55388281122",	"55388292893",	"55388292974",	"55388301280",	"55388301749",	"55388306895",	"55388326708",	"55388332896",	"55388336202",	"55388345338",	"55388345419",	"55388353276",	"55388358827",	"55388369050",	"55388377457",	"55388377538",	"55388392702",	"55388408130",	"55388417379",	"55388426112",	"55388433515",	"55388437900",	"55388437996",	"55388439633",	"55388441453",	"55388447490",	"55388450331",	"55388460083",	"55388460164",	"55388481915",	"55388488988",	"55388497834",	"55388506609",	"55388526017",	"55388533258",	"55388534004",	"55388538809",	"55388557439",	"55388565296",	"55388565377",	"55388569875",	"55388585109",	"55388588586",	"55388591314",	"55388593047",	"55388602724",	"55388605299",	"55388608761",	"55388610581",	"55388611602",	"55388619534",	"55388619615",	"55388621435",	"55388627391",	"55388627472",	"55388630232",	"55388661816",	"55388664020",	"55388685592",	"55388685673",	"55388689205",	"55388697143",	"55388702386",	"55388718160",	"55388726567",	"55388726648",	"55388741812",	"55388749776",	"55388749857",	"55388751500",	"55388760442",	"55388760523",	"55388762175",	"55388765912",	"55388773029",	"55388773850",	"55388906080",	"55388906549",	"55388914487",	"55388918985",	"55388929839",	"55388934219",	"55388937696",	"55388940424",	"55388940505",	"55388942157",	"55388953751",	"55388953832",	"55388962710",	"55388971797",	"55388997502",	"55389023071",	"55389028541",	"55389035782",	"55389046749",	"55389047171",	"55389047252",	"55389050189",	"55389054687",	"55389056130",	"55389059963",	"55389070823",	"55389073398",	"55389087633",	"55389087714",	"55389095571",	"55389104346",	"55389104427",	"55389110551",	"55389112284",	"55389136401",	"55389162628",	"55389170485",	"55389178402",	"55389178579",	"55389186340",	"55389186809",	"55389193905",	"55389194747",	"55389203053",	"55389208442",	"55389208523",	"55389217401",	"55389234669",	"55389235091",	"55389235302",	"55389236112",	"55389248904",	"55389250805",	"55389255049",	"55389256842",	"55389270132",	"55389308185",	"55389310248",	"55389316479",	"55389331756",	"55389342529",	"55389343226",	"55389350386",	"55389366322",	"55389373725",	"55389374648",	"55389374729",	"55389382586",	"55389397857",	"55389397938",	"55389399607",	"55389403797",	"55389405240",	"55389430706",	"55389436743",	"55389436824",	"55389463392",	"55389492002",	"55389494944",	"55389511738",	"55389523208",	"55389527512",	"55389527689",	"55389529245",	"55389531065",	"55389535450",	"55389535919",	"55389543857",	"55389562487",	"55389562568",	"55389566985",	"55389571527",	"55389590157",	"55389604159",	"55389605952",	"55389624663",	"55389659487",	"55389661211",	"55389661437",	"55389675623",	"55389678198",	"55389681007",	"55389682783",	"55389682864",	"55389694253",	"55389694334",	"55389701020",	"55389701101",	"55389709146",	"55389709227",	"55389711047",	"55389715383",	"55389715432",	"55389717084",	"55389723758",	"55389723839",	"55389731696",	"55389742356",	"55389746967",	"55389751509",	"55389757401",	"55389767347",	"55389767428",	"55389770960",	"55389775285",	"55389799547",	"55389823275",	"55389838320",	"55389839469",	"55389850135",	"55389851992",	"55389855605",	"55389863462",	"55389872340",	"55389880440",	"55389882173",	"55389883113",	"55389891051",	"55389894965",	"55389911678",	"55389920637",	"55389947329",	"55389948026",	"55389954150",	"55389955267",	"55389968675",	"55389979448",	"55389979529",	"55389987386",	"55390010040",	"55390013873",	"55390013954",	"55390022913",	"55390029986",	"55390038832",	"55390041543",	"55390041624",	"55390048697",	"55390049605",	"55390057462",	"55390057543",	"55390067457",	"55390069013",	"55390089581",	"55390089662",	"55390090898",	"55390090979",	"55390093377",	"55390095078",	"55390095159",	"55390106375",	"55390129584",	"55390132312",	"55390132489",	"55390134045",	"55390140250",	"55390140719",	"55390145720",	"55390163928",	"55390171866",	"55390187979",	"55390190400",	"55390192246",	"55390196889",	"55390202733",	"55390209887",	"55390209968",	"55390210752",	"55390211724",	"55390218733",	"55390218814",	"55390226671",	"55390238286",	"55390245382",	"55390258790",	"55390264287",	"55390269563",	"55390269644",	"55390273197",	"55390277889",	"55390278603",	"55390280423",	"55390295677",	"55390295758",	"55390297233",	"55390297314",	"55390301521",	"55390301634",	"55390314027",	"55390320232",	"55390340994",	"55390351767",	"55390351848",	"55390372147",	"55390373940",	"55390380085",	"55390386171",	"55390388098",	"55390388179",	"55390389940",	"55390396409",	"55390406572",	"55390406653",	"55390418042",	"55390418123",	"55390427001",	"55390427097",	"55390438691",	"55390438772",	"55390456948",	"55390458504",	"55390460324",	"55390460405",	"55390464886",	"55390466442",	"55390485072",	"55390485153",	"55390520976",	"55390541356",	"55390552129",	"55390557211",	"55390560067",	"55390561860",	"55390565618",	"55390573475",	"55390584248",	"55390584329",	"55390613397",	"55390618673",	"55390618754",	"55390620849",	"55390627713",	"55390640306",	"55390644787",	"55390644868",	"55390646343",	"55390646424",	"55390654281",	"55390660955",	"55390685914",	"55390695698",	"55390695779",	"55390700877",	"55390700958",	"55390715841",	"55390721257",	"55390737289",	"55390745050",	"55390745519",	"55390751805",	"55390753457",	"55390755126",	"55390764117",	"55390768809",	"55390772087",	"55390772168",	"55390776585",	"55390781127",	"55390792721",	"55390792802",	"55390797046",	"55390805751",	"55390813900",	"55390813996",	"55390834182",	"55390834263",	"55390856969",	"55390865928",	"55390869087",	"55390873753",	"55390885223",	"55390892383",	"55390892464",	"55390901239",	"55390906321",	"55390910970",	"55390914728",	"55390933439",	"55390937937",	"55390956567",	"55390956648",	"55390961028",	"55390977028",	"55390978740",	"55390978821",	"55390980641",	"55391008148",	"55391043880",	"55391054653",	"55391054734",	"55391055350",	"55391062591",	"55391066123",	"55391066204",	"55391073639",	"55391075001",	"55391086772",	"55391086853",	"55391092269",	"55391103566",	"55391126694",	"55391131236",	"55391139217",	"55391142830",	"55391147155",	"55391155368",	"55391159898",	"55391159979",	"55391164359",	"55391179274",	"55391181288",	"55391215924",	"55391219196",	"55391223781",	"55391223862",	"55391227200",	"55391235332",	"55391244210",	"55391255981",	"55391261478",	"55391274692",	"55391280189",	"55391283651",	"55391294424",	"55391294505",	"55391299570",	"55391300364",	"55391308426",	"55391311218",	"55391316283",	"55391327137",	"55391359175",	"55391374420",	"55391382827",	"55391385289",	"55391393050",	"55391393131",	"55391398601",	"55391403763",	"55391403844",	"55391404460",	"55391415233",	"55391415314",	"55391419795",	"55391422749",	"55391423090",	"55391425002",	"55391435882",	"55391435963",	"55391441379",	"55391456424",	"55391461996",	"55391463552",	"55391463633",	"55391471490",	"55391479471",	"55391479552",	"55391528384",	"55391530609",	"55391547095",	"55391550017",	"55391554321",	"55391554498",	"55391556054",	"55391562809",	"55391585937",	"55391593875",	"55391603072",	"55391603153",	"55391605950",	"55391609190",	"55391610588",	"55391612031",	"55391624904",	"55391632761",	"55391643534",	"55391648680",	"55391651391",	"55391651472",	"55391654226",	"55391659453",	"55391659534",	"55391667391",	"55391678439",	"55391692889",	"55391697069",	"55391702103",	"55391708285",	"55391715769",	"55391723530",	"55391731937",	"55391734303",	"55391734399",	"55391736036",	"55391742160",	"55391742241",	"55391747711",	"55391750567",	"55391750648",	"55391765919",	"55391773776",	"55391773857",	"55391793201",	"55391804805",	"55391812743",	"55391828581",	"55391828662",	"55391843069",	"55391849010",	"55391866278",	"55391870944",	"55391878957",	"55391879492",	"55391882414",	"55391886895",	"55391890271",	"55391899224",	"55391899305",	"55391903431",	"55391905164",	"55391908901",	"55391911919",	"55391916018",	"55391930080",	"55391930549",	"55391942985",	"55391953839",	"55391961696",	"55391974138",	"55391974219",	"55391975931",	"55391979220",	"55391982076",	"55391987627",	"55392001581",	"55392005339",	"55392013196",	"55392028548",	"55392033009",	"55392067812",	"55392069432",	"55392071220",	"55392071252",	"55392080130",	"55392100676",	"55392116789",	"55392125635",	"55392137105",	"55392144265",	"55392144346",	"55392157754",	"55392168608",	"55392175380",	"55392176384",	"55392176465",	"55392199593",	"55392208449",	"55392213812",	"55392216387",	"55392232442",	"55392232523",	"55392238560",	"55392240380",	"55392241401",	"55392272904",	"55392279977",	"55392280842",	"55392288904",	"55392296761",	"55392305536",	"55392305617",	"55392313474",	"55392319560",	"55392332185",	"55392345593",	"55392365406",	"55392371611",	"55392384036",	"55392384117",	"55392390241",	"55392414012",	"55392418542",	"55392420362",	"55392460743",	"55392460824",	"55392467897",	"55392468805",	"55392469502",	"55392476743",	"55392488132",	"55392488213",	"55392495648",	"55392509230",	"55392509311",	"55392517637",	"55392517718",	"55392525494",	"55392525575",	"55392526353",	"55392535344",	"55392545307",	"55392551689",	"55392553245",	"55392590985",	"55392606381",	"55392637933",	"55392644014",	"55392645871",	"55392649403",	"55392657341",	"55392664582",	"55392676052",	"55392677990",	"55392683487",	"55392692301",	"55392697803",	"55392714516",	"55392720721",	"55392733146",	"55392733227"];
			var getACNNumbers=["10753054",	"10753027",	"10753027",	"10753027",	"10753009",	"10752995",	"10752986",	"10752986",	"10752977",	"10752959",	"10752904",	"10752904",	"10752879",	"10752815",	"10752815",	"10752771",	"10752762",	"10752762",	"10752762",	"10752637",	"10752548",	"10752548",	"10752477",	"10752477",	"10752477",	"10752388",	"10752388",	"10752388",	"10752333",	"10752306",	"10752191",	"10752191",	"10752155",	"10752137",	"10752057",	"10752048",	"10751854",	"10751845",	"10751845",	"10751774",	"10751756",	"10751747",	"10751738",	"10751710",	"10751701",	"10751701",	"10751701",	"10751587",	"10751578",	"10751578",	"10751578",	"10751578",	"10751578",	"10751523",	"10751461",	"10751443",	"10751443",	"10751425",	"10751407",	"10751390",	"10751390",	"10751390",	"10751390",	"10751390",	"10751318",	"10751292",	"10751283",	"10751265",	"10751265",	"10751210",	"10751210",	"10751210",	"10751176",	"10751050",	"10751014",	"10750982",	"10750982",	"10750964",	"10750964",	"10750964",	"10750964",	"10750964",	"10750955",	"10750955",	"10750955",	"10750839",	"10750839",	"10750820",	"10750820",	"10750820",	"10750802",	"10750759",	"10750722",	"10750606",	"10750580",	"10750491",	"10750482",	"10750482",	"10750482",	"10750240",	"10750222",	"10750222",	"10750213",	"10750204",	"10750062",	"10750053",	"10750026",	"10750026",	"10749970",	"10749961",	"10749961",	"10749952",	"10749952",	"10749943",	"10749916",	"10749907",	"10749881",	"10749827",	"10749818",	"10749818",	"10749809",	"10749809",	"10749774",	"10749774",	"10749667",	"10749667",	"10749658",	"10749621",	"10749621",	"10749603",	"10749603",	"10749596",	"10749596",	"10749587",	"10749587",	"10749569",	"10749569",	"10749569",	"10749550",	"10749550",	"10749550",	"10749550",	"10749532",	"10749523",	"10749523",	"10749514",	"10749514",	"10749434",	"10749434",	"10749407",	"10749327",	"10749274",	"10749247",	"10749185",	"10749158",	"10748982",	"10748982",	"10748919",	"10748900",	"10748900",	"10748893",	"10748893",	"10748875",	"10748875",	"10748866",	"10748848",	"10748786",	"10748777",	"10748722",	"10748615",	"10748615",	"10748553",	"10748553",	"10748535",	"10748535",	"10748535",	"10748535",	"10748491",	"10748446",	"10748446",	"10748446",	"10748446",	"10748446",	"10748428",	"10748428",	"10748393",	"10748375",	"10748366",	"10748366",	"10748366",	"10748320",	"10748286",	"10748151",	"10748151",	"10748133",	"10748062",	"10748062",	"10748035",	"10748035",	"10748035",	"10748017",	"10747930",	"10747841",	"10747841",	"10747832",	"10747752",	"10747663",	"10747467",	"10747421",	"10747421",	"10747403",	"10747332",	"10747323",	"10747323",	"10747243",	"10747145",	"10747127",	"10747083",	"10747074",	"10747074",	"10747074",	"10747074",	"10747074",	"10746997",	"10746997",	"10746979",	"10746979",	"10746924",	"10746835",	"10746835",	"10746817",	"10746693",	"10746693",	"10746684",	"10746648",	"10746639",	"10746595",	"10746586",	"10746586",	"10746540",	"10746540",	"10746540",	"10746353",	"10746344",	"10746317",	"10746317",	"10746317",	"10746273",	"10746200",	"10746184",	"10746184",	"10746157",	"10746111",	"10746111",	"10746077",	"10746059",	"10746031",	"10745990",	"10745927",	"10745927",	"10745909",	"10745883",	"10745874",	"10745865",	"10745856",	"10745687",	"10745641",	"10745641",	"10745598",	"10745561",	"10745507",	"10745490",	"10745463",	"10745463",	"10745383",	"10745383",	"10745383",	"10745356",	"10745356",	"10745356",	"10745329",	"10745329",	"10745310",	"10745267",	"10745267",	"10745267",	"10744948",	"10744948",	"10744948",	"10744868",	"10744840",	"10744831",	"10744797",	"10744779",	"10744760",	"10744760",	"10744751",	"10744751",	"10744751",	"10744751",	"10744706",	"10744706",	"10744626",	"10744626",	"10744582",	"10744582",	"10744582",	"10744340",	"10744340",	"10744331",	"10744331",	"10744331",	"10744313",	"10744313",	"10744313",	"10744224",	"10743932",	"10743932",	"10743905",	"10743843",	"10743843",	"10743825",	"10743825",	"10743825",	"10743825",	"10743781",	"10743781",	"10743745",	"10743745",	"10743745",	"10743745",	"10743745",	"10743736",	"10743736",	"10743727",	"10743727",	"10743727",	"10743718",	"10743718",	"10743692",	"10743692",	"10743692",	"10743692",	"10743665",	"10743629",	"10743629",	"10743594",	"10743594",	"10743594",	"10743585",	"10743576",	"10743450",	"10743432",	"10743432",	"10743361",	"10743334",	"10743334",	"10743254",	"10743245",	"10743236",	"10743236",	"10743209",	"10743209",	"10743183",	"10743174",	"10743174",	"10743174",	"10743129",	"10743094",	"10743094",	"10743058",	"10743049",	"10742926",	"10742855",	"10742855",	"10742784",	"10742784",	"10742784",	"10742784",	"10742784",	"10742757",	"10742720",	"10742631",	"10742622",	"10742622",	"10742524",	"10742524",	"10742524",	"10742480",	"10742462",	"10742462",	"10742435",	"10742364",	"10742364",	"10742319",	"10742300",	"10742300",	"10742266",	"10742266",	"10742257",	"10742186",	"10742186",	"10742113",	"10742113",	"10742104",	"10742088",	"10742060",	"10742060",	"10742051",	"10742006",	"10741992",	"10741983",	"10741974",	"10741974",	"10741965",	"10741956",	"10741947",	"10741947",	"10741938",	"10741901",	"10741812",	"10741732",	"10741732",	"10741634",	"10741625",	"10741607",	"10741554",	"10741554",	"10741545",	"10741509",	"10741509",	"10741483",	"10741483",	"10741429",	"10741321",	"10741296",	"10741296",	"10741296",	"10741296",	"10741296",	"10741232",	"10741232",	"10741232",	"10741189",	"10741189",	"10741152",	"10741063",	"10741045",	"10741045",	"10741045",	"10741018",	"10741018",	"10740931",	"10740833",	"10740806",	"10740762",	"10740744",	"10740717",	"10740717",	"10740708",	"10740708",	"10740708",	"10740691",	"10740593",	"10740575",	"10740495",	"10740495",	"10740459",	"10740306",	"10740299",	"10740299",	"10740299",	"10740271",	"10740262",	"10740253",	"10740191",	"10740182",	"10740182",	"10740182",	"10740173",	"10740173",	"10740164",	"10740164",	"10740128",	"10740075",	"10740057",	"10739894",	"10739894",	"10739885",	"10739885",	"10739876",	"10739830",	"10739812",	"10739812",	"10739796",	"10739670",	"10739670",	"10739652",	"10739625",	"10739625",	"10739536",	"10739456",	"10739438",	"10739401",	"10739401",	"10739385",	"10739358",	"10739312",	"10739303",	"10739303",	"10739303",	"10739303",	"10739278",	"10739250",	"10739232",	"10739214",	"10739152",	"10739152",	"10739116",	"10739116",	"10739027",	"10739027",	"10738940",	"10738888",	"10738879",	"10738879",	"10738824",	"10738708",	"10738664",	"10738637",	"10738628",	"10738628",	"10738593",	"10738575",	"10738575",	"10738548",	"10738539",	"10738539",	"10738539",	"10738511",	"10738511",	"10738511",	"10738502",	"10738459",	"10738459",	"10738431",	"10738431",	"10738404",	"10738404",	"10738404",	"10738404",	"10738397",	"10738351",	"10738333",	"10738306",	"10738271",	"10738271",	"10738271",	"10738253",	"10738093",	"10738075",	"10737970",	"10737961",	"10737783",	"10737587",	"10737541",	"10737541",	"10737541",	"10737505",	"10737498",	"10737498",	"10737452",	"10737283",	"10737283",	"10737265",	"10737265",	"10737265",	"10737265",	"10737238",	"10737238",	"10737229",	"10737201",	"10737201",	"10737149",	"10737087",	"10737087",	"10736955",	"10736946",	"10736946",	"10736946",	"10736937",	"10736900",	"10736866",	"10736820",	"10736820",	"10736697",	"10736697",	"10736633",	"10736633",	"10736615",	"10736544",	"10736544",	"10736491",	"10736482",	"10736473",	"10736473",	"10736473",	"10736428",	"10736375",	"10736375",	"10736286",	"10736259",	"10736259",	"10736259",	"10736231",	"10736231",	"10736213",	"10736213",	"10736204",	"10736197",	"10736197",	"10736197",	"10736115",	"10736115",	"10736106",	"10736106",	"10736071",	"10736071",	"10736053",	"10735869",	"10735869",	"10735841",	"10735841",	"10735814",	"10735805",	"10735752",	"10735734",	"10735734",	"10735672",	"10735609",	"10735556",	"10735556",	"10735547",	"10735547",	"10735494",	"10735403",	"10735378",	"10735378",	"10735378",	"10735332",	"10735305",	"10735261",	"10735252",	"10735225",	"10735216",	"10735216",	"10735163",	"10735145",	"10735118",	"10735118",	"10735109",	"10735074",	"10735056",	"10734906",	"10734906",	"10734808",	"10734684",	"10734684",	"10734479",	"10734479",	"10734433",	"10734433",	"10734415",	"10734362",	"10734344",	"10734282",	"10734273",	"10734255",	"10734175",	"10734175",	"10734175",	"10734139",	"10734059",	"10734059",	"10734059",	"10734013",	"10734013",	"10733945",	"10733918",	"10733865",	"10733865",	"10733785",	"10733730",	"10733730",	"10733730",	"10733561",	"10733561",	"10733481",	"10733472",	"10733445",	"10733427",	"10733427",	"10733418",	"10733418",	"10733409",	"10733310",	"10733310",	"10733285",	"10733249",	"10733249",	"10733249",	"10733169",	"10733141",	"10733034",	"10733034",	"10733025",	"10732975",	"10732966",	"10732966",	"10732920",	"10732920",	"10732831",	"10732779",	"10732779",	"10732733",	"10732699",	"10732626",	"10732608",	"10732608",	"10732411",	"10732395",	"10732395",	"10732395",	"10732395",	"10732368",	"10732304",	"10732304",	"10732297",	"10732297",	"10732297",	"10732288",	"10732288",	"10732288",	"10732153",	"10732082",	"10732082",	"10732082",	"10732082",	"10732055",	"10731996",	"10731923",	"10731889",	"10731843",	"10731834",	"10731781",	"10731754",	"10731638",	"10731601",	"10731601",	"10731601",	"10731601",	"10731594",	"10731594",	"10731585",	"10731585",	"10731585",	"10731576",	"10731576",	"10731567",	"10731567",	"10731549",	"10731549",	"10731512",	"10731487",	"10731441",	"10731441",	"10731441",	"10731441",	"10731441",	"10731441",	"10731441",	"10731389",	"10731389",	"10731370",	"10731370",	"10731370",	"10731370",	"10731316",	"10731307",	"10731290",	"10731085",	"10731049",	"10731003",	"10730971",	"10730891",	"10730882",	"10730873",	"10730828",	"10730828",	"10730828",	"10730819",	"10730766",	"10730720",	"10730588",	"10730588",	"10730588",	"10730533",	"10730499",	"10730408",	"10730391",	"10730355",	"10730337",	"10730257",	"10730248",	"10730159",	"10730159",	"10730097",	"10730097",	"10730088",	"10730060",	"10730042",	"10730042",	"10730042",	"10730042",	"10730015",	"10730015",	"10730006",	"10729987",	"10729987",	"10729950",	"10729950",	"10729950",	"10729950",	"10729950",	"10729950",	"10729932",	"10729932",	"10729843",	"10729843",	"10729843",	"10729834",	"10729834",	"10729825",	"10729825",	"10729825",	"10729807",	"10729807",	"10729736",	"10729692",	"10729692",	"10729674",	"10729674",	"10729665",	"10729665",	"10729594",	"10729594",	"10729585",	"10729576",	"10729558",	"10729530",	"10729478",	"10729469",	"10729469",	"10729441",	"10729432",	"10729398",	"10729361",	"10729352",	"10729325",	"10729307",	"10729263",	"10729263",	"10729245",	"10729245",	"10729218",	"10729218",	"10729209",	"10729209",	"10729192",	"10729183",	"10729183",	"10729183",	"10729174",	"10729174",	"10729174",	"10729147",	"10729147",	"10729110",	"10729094",	"10729067",	"10729058",	"10729049",	"10728971",	"10728971",	"10728962",	"10728962",	"10728962",	"10728962",	"10728962",	"10728962",	"10728935",	"10728935",	"10728935",	"10728926",	"10728926",	"10728908",	"10728908",	"10728908",	"10728882",	"10728882",	"10728882",	"10728819",	"10728784",	"10728784",	"10728784",	"10728784",	"10728766",	"10728748",	"10728748",	"10728748",	"10728686",	"10728659",	"10728551",	"10728542",	"10728533",	"10728524",	"10728524",	"10728524",	"10728499",	"10728499",	"10728499",	"10728499",	"10728391",	"10728373",	"10728355",	"10728319",	"10728220",	"10728220",	"10728220",	"10728220",	"10728220",	"10728220",	"10728122",	"10728122",	"10728113",	"10728113",	"10728042",	"10728042",	"10727992",	"10727992",	"10727992",	"10727992",	"10727992",	"10727992",	"10727983",	"10727983",	"10727876",	"10727876",	"10727858",	"10727858",	"10727849",	"10727849",	"10727849",	"10727821",	"10727803",	"10727803",	"10727787",	"10727769",	"10727732",	"10727723",	"10727670",	"10727643",	"10727590",	"10727581",	"10727527",	"10727483",	"10727447",	"10727447",	"10727447",	"10727330",	"10727330",	"10727330",	"10727330",	"10727250",	"10727250",	"10727241",	"10727241",	"10727214",	"10727214",	"10727205",	"10727170",	"10727152",	"10727152",	"10727143",	"10727125",	"10727125",	"10727125",	"10727125",	"10727116",	"10727116"];
			var getAlphaNumericharaters=["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","~","!","@","#",",","$","%","^","&","/"];
			//for(var i=0;i<50;i++){
				//console.log(Math.floor(Math.random()*8));
			getRandomBloodGroup[i]=getBloodGroup[Math.floor(Math.random()*8)];
			
			//}
			var namesCount=0;
			var genderCount=0;
			console.log(getRandomBloodGroup);
			//var finalHtmlString="<html><head></head><body><table><tr><th>Names</th><th>Gender</th></tr></table></body></html>";
			var htmlString="<html><head></head><body><table border='1'><thead>"
			let csvString='';
			/*
			if(selectedData.includes('Names ')){
				htmlString+="<th>Names</th>";
			}
			if(selectedData.includes('Gender')){
				htmlString+="<th>Gender</th>";
			}
			htmlString+="</thead><tbody>";*/
			for(var j=0;j<selectedData.length;j++){
				console.log("Entered into Selected Data");
				htmlString+="<th>"+selectedData[j]+"</th>";
				csvString+=selectedData[j]+",";
			}
			htmlString+="</thead><tbody>";
			csvString+="\n";
			//htmlString+="<thead><tr>Names</tr><tr>Gender</tr></thead><tbody>";
			var myJson={};
			//console.log(JSON.stringify(data.results[0].id));
			
			for(var k=0;k<noofrowsSelected;k++){
				htmlString+="<tr>"
				/*****************Aadhar Generation*****************/
				if(selectedData.includes('Aadhaar')){
					//htmlString+="<th>Aadhar</th>";
					var anumber=Math.floor(Math.random()*(99999999999-444444444444+1))+444444444444;
					var astring=anumber.toString();
					console.log(astring);
					var regex = new RegExp('^[2-9]{1}[0-9]{11}$');
					//var rege=/^\d{4}\d{4}\d{4}$;
					if(regex.test(astring)){
						aadharNumbers[k]=anumber;
						htmlString+="<td>"+aadharNumbers[k]+"</td>";
						csvString+=aadharNumbers[k]+",";
					}
					else{
						aadharNumbers[k]=astring.replace('1','5');
						htmlString+="<td>"+aadharNumbers[k]+"</td>";
						csvString+=aadharNumbers[k]+",";
						console.log(aadharNumbers[k]);
					}
					}
				/*****************ABN Generation*****************/
				if(selectedData.includes('ABN')){
					htmlString+="<td>"+getABNNumbers[k]+"</td>";
					csvString+=getABNNumbers[k]+",";
				}
				/*****************ACN Generation*****************/
				if(selectedData.includes('ABN')){
					htmlString+="<td>"+getACNNumbers[k]+"</td>";
					csvString+=getACNNumbers[k]+",";
				}
				
				
				/*****************Address Generation*****************/
				if(selectedData.includes('Address')){
				//htmlString+="<th>Address</th>";
				//getaddress[k]=getnames.results[k].location.street+" "+getnames.results[k].location.city+" "+getnames.results[k].location.state;
				htmlString+="<td>"+getnames.results[k].location.street+" "+getnames.results[k].location.city+" "+getnames.results[k].location.state+"</td>";
				csvString+=getnames.results[k].location.street+" "+getnames.results[k].location.city+" "+getnames.results[k].location.state+",";
				}
				/*****************Age Generation*****************/
				if(selectedData.includes('Age')){
				//htmlString+="<th>Age</th>";
				//getages[k]=getnames.results[k].dob.age;
				htmlString+="<td>"+getnames.results[k].dob.age+"</td>";
				csvString+=getnames.results[k].dob.age+",";
				}
				
				/*****************Blood-Group Generation*****************/
				if(selectedData.includes('Blood-Group')){
				//htmlString+="<th>Blood Group</th>";
				getRandomBloodGroup[k]=getBloodGroup[Math.floor(Math.random()*8)];
				htmlString+="<td>"+getRandomBloodGroup[k]+"</td>";
				csvString+=getRandomBloodGroup[k]+",";
				}
				/*****************City Generation*****************/
				if(selectedData.includes('City')){
				//htmlString+="<th>City</th>";
				//getcity[k]=getnames.results[k].location.city;
				htmlString+="<td>"+getnames.results[k].location.city.charAt(0).toUpperCase()+getnames.results[k].location.city.slice(1)+"</td>";
				csvString+=getnames.results[k].location.city.charAt(0).toUpperCase()+getnames.results[k].location.city.slice(1)+",";
				}
				/*****************Name Generation*****************/
				if(selectedData.includes('Names')){
				
				//randomnames[k]=getnames.results[k].name.first+" "+getnames.results[k].name.last;
				//for(var k=0;k<noofrowsSelected;k++){
				htmlString+="<td>"+getnames.results[k].name.first.charAt(0).toUpperCase()+getnames.results[k].name.first.slice(1)+" "+getnames.results[k].name.last.charAt(0).toUpperCase()+getnames.results[k].name.last.slice(1)+"</td>";
				csvString+=getnames.results[k].name.first.charAt(0).toUpperCase()+getnames.results[k].name.first.slice(1)+" "+getnames.results[k].name.last.charAt(0).toUpperCase()+getnames.results[k].name.last.slice(1)+",";
				//}
				}
				/*****************Credit-Card Generation*****************/
				if(selectedData.includes('Credit-Card')){
					console.log("CreditCard Entered");
					htmlString+="<td>"+getCreditCards[k]+"</td>";
					csvString+=getCreditCards[k]+",";
				}
				
				/*****************Email Generation*****************/
				if(selectedData.includes('Email')){
				//htmlString+="<th>Email</th>";
				//getemails[k]=getnames.results[k].email;
				htmlString+="<td>"+getnames.results[k].email+"</td>";
				csvString+=getnames.results[k].email+",";
				}
				/*****************Gender Generation*****************/
				if(selectedData.includes('Gender')){
				
				
				//getgenders[k]=getnames.results[k].gender;
				//for(var k=0;k<noofrowsSelected;k++){
				htmlString+="<td>"+getnames.results[k].gender.charAt(0).toUpperCase()+getnames.results[k].gender.slice(1)+"</td>";
				csvString+=getnames.results[k].gender.charAt(0).toUpperCase()+getnames.results[k].gender.slice(1)+",";
				//}
				}
				/*****************Geo-Coordinates Generation*****************/
				if(selectedData.includes('Geo-Coordinates')){
				//htmlString+="<th>Geo-Coordinates(Latitude,Longitude)</th>";
				getcoordinates[k]=getnames.results[k].location.coordinates.latitude+" latitude"+getnames.results[k].location.coordinates.longitude+" longitude";
				htmlString+="<td>"+getcoordinates[k]+"</td>";
				csvString+=getcoordinates[k]+",";
				}
				/*****************Height Generation*****************/
				if(selectedData.includes('Height')){
				//htmlString+="<th>Geo-Coordinates(Latitude,Longitude)</th>";
				getcoordinates[k]=Math.floor(Math.random()*(7-3+1))+3;
				htmlString+="<td>"+getcoordinates[k]+" feet"+"</td>";
				csvString+=getcoordinates[k]+" feet"+",";
				}
				/*****************Occupation Generation*****************/
				if(selectedData.includes('Occupation')){
				//htmlString+="<th>Occupation</th>";
				getRandomOccupation[k]=occupation[Math.floor(Math.random()*694)];
				htmlString+="<td>"+getRandomOccupation[k]+"</td>";
				csvString+=getRandomOccupation[k]+",";
				}
				/*****************PAN Number Generation*****************/
				if(selectedData.includes('PAN')){
					var pannumber="";
					for(var m=0;m<3;m++){
						pannumber+=getCharacters[Math.floor(Math.random()*26)];
					}
					pannumber+="P"+getnames.results[k].name.first[0].toUpperCase();
					for(var i=0;i<4;i++){
						pannumber+=Math.floor(Math.random()*9);
					}
					pannumber+=getCharacters[Math.floor(Math.random()*26)];
					getPanNumbers[k]=pannumber;
					htmlString+="<td>"+getPanNumbers[k]+"</td>";
					csvString+=getPanNumbers[k]+",";
					
				}
				/*****************Phone Generation*****************/
				if(selectedData.includes('Phone')){
				//htmlString+="<th>Phone Number</th>";
				//getphones[k]=getnames.results[k].phone;
				htmlString+="<td>"+getnames.results[k].phone+"</td>";
				csvString+=getnames.results[k].phone+",";
				}
				/*****************SSN Generation*****************/
				if(selectedData.includes('SSN')){
				//htmlString+="<th>SSN</th>";
				//getssn[k]=getnames.results[k].id.value;
				htmlString+="<td>"+getnames.results[k].id.value+"</td>";
				csvString+=getnames.results[k].id.value+",";
				}
				/*****************State Generation*****************/
				if(selectedData.includes('State')){
				//htmlString+="<th>State</th>";
				//getstate[k]=getnames.results[k].location.state;
				htmlString+="<td>"+getnames.results[k].location.state.charAt(0).toUpperCase()+getnames.results[k].location.state.slice(1)+"</td>";
				csvString+=getnames.results[k].location.state.charAt(0).toUpperCase()+getnames.results[k].location.state.slice(1)+",";
				}
				/*****************Weight Generation*****************/
				if(selectedData.includes('Weight')){
				//htmlString+="<th>Weight</th>";
				getWeights[k]=(getnames.results[k].dob.age)*4+" lbs";
				htmlString+="<td>"+getWeights[k]+"</td>";
				csvString+=getWeights[k]+",";
				}
				/*****************ZipCode Generation*****************/
				if(selectedData.includes('Zip')){
				//htmlString+="<th>Zip Code</th>";
				//getpostcode[k]=getnames.results[k].location.postcode;
				htmlString+="<td>"+getnames.results[k].location.postcode+"</td>";
				csvString+=getnames.results[k].location.postcode+",";
				}
				/*****************Zodiac-Sign Generation*****************/
				if(selectedData.includes('Zodiac-Sign')){
				//htmlString+="<th>Zodiac Sign</th>";
				getZodiacSign[k]=ZodiacSigns[Math.floor(Math.random()*14)];
				htmlString+="<td>"+getZodiacSign[k]+"</td>";
				csvString+=getZodiacSign[k]+",";
				}
				//var months=getnames.results[k].dob.date.split("-");
				//if(months[1]=="01"){
					//getZodiacSign[k]="Saggitarius";
				//}
				//else if(months[1]=="02){
					
				//}
				//if(selectedData.includes('Aadhaar')){
				//for(var k=0;k<noofrowsSelected;k++){
					//if(selectedData.includes('Aaadhar')){
					
					htmlString+="</tr>";
					csvString+="\n";



					
					//}
				
			
			}
			htmlString+="</tbody></table></body></html>";
			//var finalHtmlString=htmlString+"</table></body></html>";
			console.log(randomnames);
			
			for(var i=0;i<selectedData.length;i++){
			if(selectedData.includes('Age')){
				for(var j=0;j<noofrowsSelected;j++){
					age[j]=Math.floor(Math.random() * (80 - 20 + 1)) + 20;
					totalAge[j]=age[j];
				
					
				}
			}
			if(selectedData.includes('Phone')){
				for(var k=0;k<noofrowsSelected;k++){
					phoneNumber[k]=Math.floor(Math.random()*(9999999999-6666666666+1))+6666666666;
					
					
				}
			}
			
			if(selectedData.includes('Email')){
				var chars = 'abcdefghijklmnopqrstuvwxyz1234567890';
				var string = '';
				for(var k=0;k<noofrowsSelected;k++){
					
				emailAddress[k]=names[k]+'@gmail.com';
				}
			}
		}
		//var totalString=finalHtmlString+htmlString;
		var jsonString = JSON.stringify(age);
		console.log(age);
		console.log(totalAge);
		console.log(jsonString);
		console.log(aadharNumbers);
		if(formatSelected=='JSON'){
		exportToJsonFile(age);
		}
		//var selectedDataClubbedArray[0]=getages;
		else if(formatSelected=='CSV'){
			console.log(names);
			//exportToCsvFile(getages,randomnames,getphones,getcity,aadharNumbers,getstate,getpostcode,getemails,getcoordinates,getaddress,getssn,getRandomBloodGroup,getRandomOccupation,getWeights,getZodiacSign);
			exportToCsvFile(csvString);
		}
		else if(formatSelected=='HTML'){
			//exportToHtmlFile(getages,randomnames,getphones,getcity,aadharNumbers,getstate,getpostcode,getemails,getcoordinates,getaddress,getssn,getRandomBloodGroup,getRandomOccupation,getWeights,getZodiacSign);
			//exportToHtmlFile(finalHtmlString);
			//exportToHtmlFile(selectedDataClubbedArray);
			//exportToHtmlFile(data);
			exportToHtmlFile(htmlString);
		}
		}
		});
		
		//console.log(randomNames);
		
		
	}
	function exportToJsonFile(jsonData) {
    let dataStr = JSON.stringify(jsonData);
    let dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    let exportFileDefaultName = 'data.json';
    
    let linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
}
function parseJSONToCSVStr(getages,randomnames,getphones,getcity,aadharNumbers,getstate,getpostcode,getemails,getcoordinates,getaddress,getssn,getRandomBloodGroup,getRandomOccupation,getWeights,getZodiacSign) {
	
    let columnDelimiter = ',';
    let lineDelimiter = '\n';
    
    let csvStr = "Age,Name,phone,City,Aadhar,State,PostCode,Email\n";//+keys.join(lineDelimiter);
	
	let finalCsvStr=csvStr;
	for(var i=0;i<getages.length;i++){
		finalCsvStr+=getages[i]+","+randomnames[i]+","+getphones[i]+","+","+","+getcity[i]+","+aadharNumbers[i]+","+","+getstate[i]+","+getpostcode[i]+","+getemails[i]+","+getcoordinates[i]+","+getaddress[i]+","+getssn[i]+","+getRandomBloodGroup[i]+","+getRandomOccupation[i]+","+getWeights[i]+","+getZodiacSign[i]+lineDelimiter;
	}
	console.log(finalCsvStr);
	
	
    return encodeURIComponent(finalCsvStr);
}

//var fname=document.getElementById("name").innerHTML;
//console.log(fname);
function exportToCsvFile(data){//exportToCsvFile(getages,randomnames,getphones,getcity,aadharNumbers,getstate,getpostcode,getemails,getcoordinates,getaddress,getssn,getRandomBloodGroup,getRandomOccupation,getWeights,getZodiacSign) {
	//console.log(names);
    let csvStr = data;//parseJSONToCSVStr(getages,randomnames,getphones,getcity,aadharNumbers,getstate,getpostcode,getemails,getcoordinates,getaddress,getssn,getRandomBloodGroup,getRandomOccupation,getWeights,getZodiacSign);
    let dataUri = 'data:text/csv;charset=utf-8,'+ csvStr;
    
    let exportFileDefaultName = fname+'.csv';
    
    let linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
}
function exportToHtmlFile(data){//exportToHtmlFile(getages,randomnames,getphones,getcity,aadharNumbers,getstate,getpostcode,getemails,getcoordinates,getaddress,getssn,getRandomBloodGroup,getRandomOccupation,getWeights,getZodiacSign) {
	//console.log(names);
	/*
	var myHtmlString="<html><head></head><body><table>";
	console.log(data.results.length);
	var mySelectedData=['email'];
	//console.log(mySelectedData[0]);
	//console.log(data.results[0].mySelectedData[0]);
	//var resultsSet=JSON.stringify(data.results);
	//console.log(resultsSet[0]);
	for(var j=0;j<mySelectedData.length;j++){
	for(var i=0;i<data.results.length;i++){
		myHtmlString+="<tr><td>"+data.results[i].dob.age+"</td></tr>"
		
	}
	}*/
	console.log(data);
    //let csvStr = parseJSONToHtmlStr(data);//parseJSONToHtmlStr(getages,randomnames,getphones,getcity,aadharNumbers,getstate,getpostcode,getemails,getcoordinates,getaddress,getssn,getRandomBloodGroup,getRandomOccupation,getWeights,getZodiacSign);
    let dataUri = 'data:text/html;charset=utf-8,'+ data;
    
    let exportFileDefaultName = fname+'.html';
    
    let linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
}

